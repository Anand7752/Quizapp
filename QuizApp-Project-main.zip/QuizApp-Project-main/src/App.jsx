import React from 'react'
import QuizApp from './QuizApp'

export default function App() {
  return (
    <div>
      <QuizApp />
    </div>
  )
}
